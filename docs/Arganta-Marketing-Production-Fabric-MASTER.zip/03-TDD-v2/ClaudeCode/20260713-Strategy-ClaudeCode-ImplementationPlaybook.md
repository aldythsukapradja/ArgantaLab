---
title: Claude Code Implementation Playbook
date: 20260713
category: Strategy
status: Ready
owner_llm: Opus
tags:
  - claude-code
  - implementation
  - parallel-workstreams
---

# Claude Code Implementation Playbook

## Objective

Use Claude Code as a coordinated engineering organization rather than one long chat.

Each workstream should have:

- One branch
- One owner model
- One worktree
- One self-contained TDD
- One public contract
- One definition of done
- One integration checkpoint

## Phase 0 — Repository Preparation

### Step 1 — Create the integration branch

```bash
git checkout main
git pull
git checkout -b feat/marketing-production-fabric
```

Do not implement directly on `main`.

### Step 2 — Create worktrees

Create one worktree per active workstream.

```bash
mkdir -p ../arganta-worktrees

git worktree add ../arganta-worktrees/creative-core -b feat/creative-core
git worktree add ../arganta-worktrees/asset-registry -b feat/asset-registry
git worktree add ../arganta-worktrees/media-core -b feat/media-core
git worktree add ../arganta-worktrees/website-builder -b feat/website-builder
git worktree add ../arganta-worktrees/scene-system -b feat/scene-system
git worktree add ../arganta-worktrees/render-engine -b feat/render-engine
```

Add more worktrees only when the interfaces are stable enough.

### Step 3 — Add the TDD package to the repo

Recommended location:

```text
docs/marketing-production-fabric/
```

Copy this package there.

### Step 4 — Create a shared contracts branch first

```bash
git checkout feat/marketing-production-fabric
git checkout -b feat/marketing-contracts
```

Implement only the contracts from the `Contracts/` folder.

Merge this branch before the other workstreams begin relying on package imports.

## Phase 1 — Contract Freeze

Before coding features, publish:

- Creative document schema
- Asset contract
- Media job contract
- Scene contract
- Render contract
- Brand profile contract
- Common error contract

The first contract version does not need to be perfect.

It must be:

- Explicit
- Versioned
- Testable
- Narrow
- Stable enough for mocks

### Contract Freeze Rule

After workstreams begin:

- Additive changes are allowed
- Breaking changes require an ADR
- Breaking changes require migration notes
- Internal implementation details must never leak into contracts

## Phase 2 — Start Parallel Workstreams

### Workstream launch pattern

Open Claude Code inside the relevant worktree.

Provide exactly:

1. The workstream TDD
2. The shared contract files
3. The relevant current repo paths
4. The instruction to work only inside owned paths

### Standard launch prompt

```text
You are the sole implementation owner of this workstream.

Read:
- the attached workstream TDD
- the shared contracts
- the current Arganta repository structure

Rules:
- preserve GitHub + Supabase + Vercel
- do not modify another workstream's owned paths
- do not invent cross-workstream implementation details
- use mocks for unavailable dependencies
- keep all public interfaces aligned with shared contracts
- build end to end
- include tests, migrations, docs, and a final handoff note
- do not stop for minor ambiguity; choose the safest compatible implementation
```

## Phase 3 — Workstream Execution Loop

Each Claude Code session should follow this order.

### 1. Audit

Ask Claude Code to inspect only the relevant repo areas.

Expected output:

- Current state
- Existing reusable packages
- Conflicts
- Proposed file tree
- Risks

### 2. Plan

Require a written implementation plan before code edits.

The plan must list:

- Files to add
- Files to modify
- Database migrations
- Tests
- Public interfaces
- Rollback strategy

### 3. Scaffold

Create:

- Package structure
- Types
- Mock adapters
- Tests
- Documentation
- Feature flags

### 4. Implement the happy path

Complete one end-to-end path before adding variants.

Example:

```text
Submit media job
→ persist job
→ mock provider completes
→ asset registered
→ UI receives realtime update
```

### 5. Add failure handling

Require:

- Retries
- Timeout handling
- Error normalization
- Idempotency
- Cancellation where supported
- Logging

### 6. Add tests

Minimum:

- Unit tests
- Contract tests
- Integration tests
- Migration checks
- One end-to-end smoke test

### 7. Self-review

Prompt Claude Code:

```text
Review your implementation as a strict staff engineer.
Find architectural violations, contract drift, hidden coupling, missing tests,
security issues, Supabase RLS gaps, Vercel runtime risks, and provider lock-in.
Fix all high and medium severity issues.
```

### 8. Produce handoff

Every branch must include:

```text
docs/handoffs/<workstream>.md
```

The handoff should include:

- What changed
- Public interfaces
- Environment variables
- Migrations
- Tests
- Known limitations
- Integration steps
- Rollback steps

## Phase 4 — Fable Review Checkpoints

Invoke Fable only after a functional milestone.

Do not send unfinished code.

Use Fable for:

- Website visual hierarchy
- Presentation pacing
- 3D lighting and camera
- Social template quality
- Campaign wow effect

Fable returns recommendations.

The original workstream owner applies them.

## Phase 5 — Integration Order

Recommended merge order:

1. Contracts
2. Creative Document Core
3. Asset Registry
4. Brand System
5. Media Core
6. MCP Gateway
7. 3D Scene System
8. Render Engine
9. Website Builder
10. Presentation Builder
11. Social Studio
12. Campaign Studio
13. HQ Integration

This is the merge order, not the start order.

## Phase 6 — Pull Request Standard

Every PR must include:

- Workstream
- Scope
- Owned paths
- Contract changes
- Migration list
- Screenshots or recordings
- Test evidence
- Cost impact
- Security impact
- Rollback plan

## Claude Model Selection

### Use Opus when

- Defining ontology
- Designing shared contracts
- Writing RLS strategy
- Making cross-package decisions
- Designing maturation and approval logic
- Reviewing multi-workstream integration
- Resolving architectural conflicts

### Use Sonnet when

- Implementing packages
- Wiring Supabase
- Building React UI
- Writing adapters
- Creating tests
- Implementing MCP tools
- Building render pipelines
- Refactoring scoped modules

## Context Management

Do not load the entire monorepo into every Claude Code session.

Provide:

- One TDD
- One or two shared contract files
- Only relevant package directories
- Exact owned paths

Ask Claude Code to summarize large files before editing them.

## Anti-Patterns

Never allow:

- Direct provider calls from UI components
- API secrets in the browser
- Cross-workstream imports from private folders
- Unversioned schemas
- Generated assets without provenance
- Premium provider usage without cost policy
- Rendering jobs tied to browser lifetime
- Brand rules hardcoded in individual templates
- Fable recommendations committed without engineering review

## Weekly Operating Cadence

### Monday

- Contract review
- Branch health
- blocker resolution

### Midweek

- Functional demos
- Fable reviews where applicable
- integration smoke tests

### End of week

- merge eligible branches
- run full integration suite
- update architecture notes
- record new risks and decisions
