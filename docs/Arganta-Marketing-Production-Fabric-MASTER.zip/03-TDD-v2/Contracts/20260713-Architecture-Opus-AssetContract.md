---
title: Asset Contract
date: 20260713
category: Architecture
owner_llm: Opus
status: Draft
---

# Asset Contract

## Purpose

This contract is the only supported dependency surface for related workstreams.

## TypeScript Reference

```ts
export interface MediaAsset {
  id: string;
  projectId?: string;
  kind: 'image' | 'video' | 'audio' | 'scene' | 'document' | 'archive';
  mimeType: string;
  storagePath: string;
  checksum?: string;
  provenanceStatus: 'complete' | 'partial' | 'unknown' | 'manual';
  approvalStatus: 'draft' | 'candidate' | 'approved' | 'published' | 'archived';
  createdBy: ActorRef;
  createdAt: string;
}
```

## Rules

- Additive changes are preferred
- Breaking changes require schema versioning
- Implementations may extend internally
- Consumers must not rely on undocumented fields
