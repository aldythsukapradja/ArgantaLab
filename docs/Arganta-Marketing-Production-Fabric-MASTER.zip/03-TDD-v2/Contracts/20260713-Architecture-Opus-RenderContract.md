---
title: Render Contract
date: 20260713
category: Architecture
owner_llm: Opus
status: Draft
---

# Render Contract

## Purpose

This contract is the only supported dependency surface for related workstreams.

## TypeScript Reference

```ts
export interface RenderRequest {
  documentId: string;
  presetId: string;
  output: {
    width: number;
    height: number;
    format: 'png' | 'jpg' | 'webm' | 'mp4' | 'html';
    fps?: number;
  };
}
```

## Rules

- Additive changes are preferred
- Breaking changes require schema versioning
- Implementations may extend internally
- Consumers must not rely on undocumented fields
