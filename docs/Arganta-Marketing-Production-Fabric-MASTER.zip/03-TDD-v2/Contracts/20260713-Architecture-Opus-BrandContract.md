---
title: Brand Contract
date: 20260713
category: Architecture
owner_llm: Opus
status: Draft
---

# Brand Contract

## Purpose

This contract is the only supported dependency surface for related workstreams.

## TypeScript Reference

```ts
export interface BrandProfile {
  id: string;
  version: number;
  name: string;
  colors: Record<string, string>;
  typography: Record<string, string>;
  motion: Record<string, unknown>;
  scene: Record<string, unknown>;
  voice: Record<string, unknown>;
  hardRules: BrandRule[];
  softRules: BrandRule[];
}
```

## Rules

- Additive changes are preferred
- Breaking changes require schema versioning
- Implementations may extend internally
- Consumers must not rely on undocumented fields
