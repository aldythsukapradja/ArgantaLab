---
title: MediaJob Contract
date: 20260713
category: Architecture
owner_llm: Opus
status: Draft
---

# MediaJob Contract

## Purpose

This contract is the only supported dependency surface for related workstreams.

## TypeScript Reference

```ts
export interface MediaJob {
  id: string;
  intent: string;
  stage: MaturityStage;
  status: 'queued' | 'submitted' | 'processing' | 'succeeded' | 'failed' | 'cancelled';
  requestedProvider?: string;
  selectedProvider?: string;
  estimatedCostUsd?: number;
  actualCostUsd?: number;
  inputAssetIds: string[];
  outputAssetIds: string[];
  createdAt: string;
  updatedAt: string;
}
```

## Rules

- Additive changes are preferred
- Breaking changes require schema versioning
- Implementations may extend internally
- Consumers must not rely on undocumented fields
