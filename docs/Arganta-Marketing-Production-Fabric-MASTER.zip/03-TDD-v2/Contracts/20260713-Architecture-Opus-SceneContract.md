---
title: Scene Contract
date: 20260713
category: Architecture
owner_llm: Opus
status: Draft
---

# Scene Contract

## Purpose

This contract is the only supported dependency surface for related workstreams.

## TypeScript Reference

```ts
export interface SceneDefinition {
  id: string;
  schemaVersion: number;
  environmentId?: string;
  camera: CameraDefinition;
  objects: SceneObject[];
  timeline: SceneTimelineEvent[];
  qualityTier: 'mobile' | 'standard' | 'cinematic';
}
```

## Rules

- Additive changes are preferred
- Breaking changes require schema versioning
- Implementations may extend internally
- Consumers must not rely on undocumented fields
