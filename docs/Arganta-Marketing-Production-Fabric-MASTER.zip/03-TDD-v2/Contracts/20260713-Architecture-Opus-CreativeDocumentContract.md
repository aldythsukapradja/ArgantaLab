---
title: CreativeDocument Contract
date: 20260713
category: Architecture
owner_llm: Opus
status: Draft
---

# CreativeDocument Contract

## Purpose

This contract is the only supported dependency surface for related workstreams.

## TypeScript Reference

```ts
export type CreativeDocumentType =
  | 'website'
  | 'presentation'
  | 'video'
  | 'social_post'
  | 'carousel'
  | 'story'
  | 'campaign'
  | 'scene';

export interface CreativeDocument {
  id: string;
  schemaVersion: number;
  type: CreativeDocumentType;
  projectId: string;
  brandProfileId: string;
  maturityStage: MaturityStage;
  format: OutputFormat;
  nodes: CreativeNode[];
  timeline?: CreativeTimeline;
  status: 'draft' | 'review' | 'approved' | 'published' | 'archived';
  version: number;
}
```

## Rules

- Additive changes are preferred
- Breaking changes require schema versioning
- Implementations may extend internally
- Consumers must not rely on undocumented fields
