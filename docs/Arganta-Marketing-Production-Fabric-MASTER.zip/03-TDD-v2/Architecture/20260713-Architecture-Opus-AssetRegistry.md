---
title: AssetRegistry
date: 20260713
category: Architecture
owner_llm: Opus
status: Ready
tags:
  - arganta
  - workstream
  - assetregistry
---

# AssetRegistry

## Executive Summary

Design the universal asset registry, lineage graph, provenance, rights, approvals, and Supabase RLS model.

This workstream must be independently executable using stable contracts and mocks.

## Sole Owner

**Opus**

Do not split implementation ownership with another model.

## Mission

Design the universal asset registry, lineage graph, provenance, rights, approvals, and Supabase RLS model.

## Owned Repository Paths

- `packages/asset-registry`
- `supabase/migrations`
- `apps/hq/src/surfaces/assets`

The owner may propose changes outside these paths but must not make them without integration review.

## Required Inputs

- Shared contracts in `docs/marketing-production-fabric/Contracts`
- Existing Arganta repo conventions
- GitHub, Supabase, and Vercel constraints
- Relevant environment variable conventions
- Existing HQ design tokens and shared packages

## Scope

- Audit current state
- Define public interfaces
- Scaffold package structure
- Implement the end-to-end happy path
- Add failure handling
- Add tests
- Add documentation
- Add integration fixtures
- Produce a branch handoff note

## Out of Scope

- Replacing GitHub, Supabase, or Vercel
- Implementing another workstream's internals
- Direct provider integration from UI
- Cross-package imports from private folders
- Unapproved schema-breaking changes

## Required Deliverables

- asset schema
- relations graph
- RLS
- provenance UI
- deletion safety

## Public Interface Rule

All external dependencies must use shared contracts or documented adapters.

Mocks must be provided for unavailable services.

## Implementation Steps

### Step 1 — Audit

Inspect only owned and directly related paths.

Produce:
- current-state summary
- reusable code map
- gap list
- risks
- proposed file tree

### Step 2 — Architecture

Define:
- public interfaces
- state boundaries
- persistence model
- error model
- feature flags
- migration impact

### Step 3 — Scaffold

Create:
- package entry points
- types
- adapters
- test setup
- fixtures
- README
- handoff template

### Step 4 — Happy Path

Implement one complete vertical path before secondary features.

### Step 5 — Failure Modes

Add:
- validation
- retries
- idempotency
- timeout behavior
- cancellation where relevant
- normalized errors
- logs

### Step 6 — Security and Governance

Verify:
- no secrets reach browser code
- Supabase RLS is explicit
- actor identity is preserved
- costs and provenance are recorded where applicable
- premium operations require policy approval

### Step 7 — Tests

Minimum:
- unit tests
- contract tests
- integration test
- one smoke test
- migration checks where relevant

### Step 8 — Documentation

Add:
- README
- environment variables
- API examples
- integration notes
- limitations
- rollback

### Step 9 — Self Review

Run a strict staff-engineer review and fix all high and medium issues.

### Step 10 — Handoff

Create:

```text
docs/handoffs/AssetRegistry.md
```

## Acceptance Criteria

- Builds and type-checks
- Tests pass
- Workstream runs against mocks
- Public contracts are respected
- No hidden coupling
- Offline development remains possible where relevant
- Stack remains GitHub + Supabase + Vercel
- Handoff documentation is complete

## Definition of Done

The branch can be reviewed and merged without requiring unfinished internal code from another workstream.

## Fable Checkpoint

Fable is not required for this workstream.

## Claude Code Launch Prompt

```text
You are the sole owner of AssetRegistry.

Read this TDD and the shared contracts.
Audit the relevant Arganta repository paths.
Preserve GitHub, Supabase, and Vercel.
Work only in the owned paths unless a documented proposal is required.
Use mocks for missing dependencies.
Implement the workstream end to end.
Include tests, documentation, environment variables, migrations, and a handoff note.
Do not stop for minor ambiguity.
```
