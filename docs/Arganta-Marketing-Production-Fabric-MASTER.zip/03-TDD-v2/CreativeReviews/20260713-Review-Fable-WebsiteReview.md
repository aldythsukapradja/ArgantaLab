---
title: WebsiteReview
date: 20260713
category: Review
owner_llm: Fable
status: Optional
---

# WebsiteReview

## When to Invoke

Invoke only after a functional milestone exists.

## Review Mission

Review the functioning Website Builder and first landing-page template for hierarchy, polish, responsiveness, cinematic pacing, brand coherence, and wow effect.

## Inputs

- Working preview
- Screenshots or video capture
- Brand profile
- Intended audience
- Campaign objective
- Known technical constraints

## Required Output

- Strengths
- High-priority visual issues
- Narrative issues
- Motion and camera recommendations
- Brand consistency issues
- Exact recommendations ranked by impact
- No code changes

## Handoff Rule

Return recommendations to the original Opus or Sonnet owner.
Fable does not become the implementation owner.
