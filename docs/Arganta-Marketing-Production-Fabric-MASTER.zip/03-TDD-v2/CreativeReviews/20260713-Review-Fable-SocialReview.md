---
title: SocialReview
date: 20260713
category: Review
owner_llm: Fable
status: Optional
---

# SocialReview

## When to Invoke

Invoke only after a functional milestone exists.

## Review Mission

Review the functioning Social Studio templates for platform-native composition, hook strength, safe zones, legibility, pacing, and brand consistency.

## Inputs

- Working preview
- Screenshots or video capture
- Brand profile
- Intended audience
- Campaign objective
- Known technical constraints

## Required Output

- Strengths
- High-priority visual issues
- Narrative issues
- Motion and camera recommendations
- Brand consistency issues
- Exact recommendations ranked by impact
- No code changes

## Handoff Rule

Return recommendations to the original Opus or Sonnet owner.
Fable does not become the implementation owner.
