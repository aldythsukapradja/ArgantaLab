---
title: PresentationReview
date: 20260713
category: Review
owner_llm: Fable
status: Optional
---

# PresentationReview

## When to Invoke

Invoke only after a functional milestone exists.

## Review Mission

Review the functioning cinematic presentation player for narrative pacing, transitions, typography, scene rhythm, mobile usability, and executive-level polish.

## Inputs

- Working preview
- Screenshots or video capture
- Brand profile
- Intended audience
- Campaign objective
- Known technical constraints

## Required Output

- Strengths
- High-priority visual issues
- Narrative issues
- Motion and camera recommendations
- Brand consistency issues
- Exact recommendations ranked by impact
- No code changes

## Handoff Rule

Return recommendations to the original Opus or Sonnet owner.
Fable does not become the implementation owner.
