---
title: Parallel Execution Map
date: 20260713
category: Strategy
status: Ready
---

# Parallel Execution Map

## Can Everything Start in Parallel?

Yes, with one condition:

> Every workstream starts against stable contracts and mocks, not another workstream's unfinished implementation.

## Day-One Parallel Set

- Creative Document Core — Opus
- Asset Registry — Opus
- Brand System — Opus
- Campaign Studio — Opus
- Media Core — Sonnet
- MCP Gateway — Sonnet using mock domain services
- Website Builder — Sonnet using mock assets and scene components
- Presentation Builder — Sonnet using mock scene renderer
- Scene System — Sonnet
- Render Engine — Sonnet using fixture documents
- Social Studio — Sonnet using fixture campaigns
- HQ Integration — Opus using interface-level integration map

## Integration Gates

### Gate A — Contract Freeze

Required before real package linking.

### Gate B — Persistence Freeze

Supabase table names, RLS responsibilities, and event payloads stabilize.

### Gate C — Asset and Job Integration

Media jobs create registered assets.

### Gate D — Creative Output Integration

Website, presentation, scene, render, and social systems consume the same document and asset IDs.

### Gate E — HQ Governance

Approvals, budgets, provider health, and maturity become visible in HQ.

## Parallel Independence Test

A workstream is sufficiently independent when:

- It builds against mocks
- Its tests do not require another branch
- Its public interface is documented
- Its internal folders are not imported elsewhere
- It can produce a handoff artifact independently
