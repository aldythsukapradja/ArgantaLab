---
title: Arganta Marketing Production Fabric V2
date: 20260713
category: Strategy
status: Ready
tags:
  - arganta
  - marketing
  - architecture
  - claude-code
---

# Arganta Marketing Production Fabric V2

## Executive Summary

This package turns the Arganta marketing production strategy into parallel, independently executable workstreams for Claude Code.

The system remains on:

- GitHub
- Supabase
- Vercel

No workstream is allowed to replace those foundations.

## Core Outcome

Build one production fabric that can create and reuse:

- Websites
- Cinematic HTML presentations
- Reusable 3D scenes
- Image and video assets
- Instagram posts and stories
- TikTok and YouTube Shorts
- Campaign packs
- Product launch materials
- Brand-consistent templates

## Single-Owner Rule

Each workstream has one implementation owner:

- Opus for architecture, governance, ontology, cross-system design
- Sonnet for scoped implementation, testing, wiring, and delivery

Fable is not an implementation owner. Fable is invoked only at explicit creative checkpoints.

## Parallel Execution Principle

All workstreams may start in parallel using stable contracts and mocks.

No workstream may import another workstream's internal code directly.

Every workstream must depend only on:

- Published contracts
- Mock adapters
- Supabase schemas
- Shared test fixtures
- Documented public interfaces

## Recommended First Vertical Slice

The first integrated proof should produce:

1. One Arganta campaign brief
2. One reusable 3D reactor scene
3. One landing page
4. One cinematic presentation
5. One 16:9 launch video
6. One 9:16 vertical video
7. One Instagram post
8. One Instagram story
9. One asset lineage graph
10. One provider and cost record

## Package Map

- `ClaudeCode/` — exact operating strategy
- `Contracts/` — stable shared interfaces
- `Architecture/` — Opus-owned workstreams
- `Build/` — Sonnet-owned workstreams
- `CreativeReviews/` — Fable review checkpoints
