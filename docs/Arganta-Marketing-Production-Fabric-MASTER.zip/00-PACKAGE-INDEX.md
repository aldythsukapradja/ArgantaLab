# Arganta Marketing Production Fabric — Master Package

## Recommended Reading Order

1. `README-CLAUDE-CODE-TUTORIAL.md`
2. `03-TDD-v2/00-START-HERE.md`
3. `03-TDD-v2/01-PARALLEL-EXECUTION-MAP.md`
4. `03-TDD-v2/ClaudeCode/20260713-Strategy-ClaudeCode-ImplementationPlaybook.md`
5. The relevant single workstream TDD

## Included Packages

- `01-Original-Workstreams/`
- `02-Parallel-Workstreams/`
- `03-TDD-v2/`
- `99-Previous-Zip-Archives/`

Use `03-TDD-v2/` as the implementation source of truth.
