---
title: Arganta Marketing Production Fabric Master Tutorial
date: 20260713
category: Strategy
status: Ready
tags:
  - arganta
  - claude-code
  - implementation
  - marketing
  - workstreams
---

# Arganta Marketing Production Fabric — Master Claude Code Tutorial

## What This Package Contains

This master package combines all prior materials:

1. Original workstream package
2. Independent parallel workstream package
3. Execution-grade TDD V2 package
4. Previous ZIP archives
5. This implementation tutorial

Use the V2 TDD package as the source of truth for implementation.

Recommended folder:

```text
03-TDD-v2/
```

The previous packages remain included for reference, comparison, and historical context.

---

# Recommended Source of Truth

Use these files first:

```text
03-TDD-v2/00-START-HERE.md
03-TDD-v2/01-PARALLEL-EXECUTION-MAP.md
03-TDD-v2/ClaudeCode/20260713-Strategy-ClaudeCode-ImplementationPlaybook.md
```

Then open only the specific workstream TDD needed for each Claude Code session.

---

# Foundation Rules

The implementation must preserve:

- GitHub as source control and CI/CD
- Supabase as authentication, database, storage, realtime, and job memory
- Vercel as application deployment, previews, and lightweight APIs

Do not introduce a replacement platform unless a proven limitation appears later.

The architecture must follow:

```text
GitHub
  = source, contracts, templates, CI/CD

Supabase
  = identity, data, jobs, assets, provenance, approvals, costs

Vercel
  = HQ UI, previews, APIs, MCP access

External providers
  = replaceable execution adapters
```

---

# Core Implementation Strategy

## Principle 1 — Start Everything Against Contracts and Mocks

All workstreams may start in parallel.

They must not depend on another unfinished workstream's internal implementation.

Each workstream should use:

- Shared contracts
- Mock adapters
- Fixtures
- Stable IDs
- Documented public interfaces

## Principle 2 — One Owner Model Per Workstream

Use:

- Opus for architecture, ontology, governance, contracts, cross-system decisions
- Sonnet for implementation, integration, tests, migrations, and UI
- Fable only as a creative reviewer after functional milestones

Do not split implementation ownership between multiple models inside one workstream.

## Principle 3 — Merge Order Is Not Start Order

Workstreams may begin in parallel.

Merge in this order:

1. Shared contracts
2. Creative Document Core
3. Asset Registry
4. Brand System
5. Media Core
6. MCP Gateway
7. 3D Scene System
8. Render Engine
9. Website Builder
10. Presentation Builder
11. Social Studio
12. Campaign Studio
13. HQ Integration

---

# Step 1 — Add the Package to ArgantaLab

Extract this package.

Copy the V2 folder into:

```text
ArgantaLab/docs/marketing-production-fabric/
```

Recommended result:

```text
ArgantaLab/
├── apps/
├── packages/
├── supabase/
├── docs/
│   └── marketing-production-fabric/
│       ├── 00-START-HERE.md
│       ├── 01-PARALLEL-EXECUTION-MAP.md
│       ├── Architecture/
│       ├── Build/
│       ├── Contracts/
│       ├── CreativeReviews/
│       └── ClaudeCode/
└── package.json
```

Commit planning documents separately:

```bash
git checkout main
git pull
git checkout -b docs/marketing-production-fabric
git add docs/marketing-production-fabric
git commit -m "docs: add marketing production fabric implementation package"
git push -u origin docs/marketing-production-fabric
```

Merge this documentation PR before implementation.

---

# Step 2 — Create the Program Integration Branch

```bash
git checkout main
git pull
git checkout -b feat/marketing-production-fabric
git push -u origin feat/marketing-production-fabric
```

This branch is the integration target for all workstreams.

Do not implement directly on `main`.

---

# Step 3 — Build Shared Contracts First

Create:

```bash
git checkout feat/marketing-production-fabric
git checkout -b feat/marketing-contracts
```

Open Claude Code in the repository.

Give it only:

```text
docs/marketing-production-fabric/Contracts/
docs/marketing-production-fabric/00-START-HERE.md
```

Recommended prompt:

```text
You are the sole owner of the Arganta Marketing Fabric shared contracts.

Read the contract documents in:
docs/marketing-production-fabric/Contracts

Implement versioned TypeScript and Zod contracts for:
- CreativeDocument
- MediaAsset
- MediaJob
- SceneDefinition
- RenderRequest
- BrandProfile

Rules:
- preserve GitHub, Supabase, and Vercel
- create additive, versioned contracts
- add fixtures and contract tests
- do not implement domain services yet
- do not leak provider-specific types into public contracts
- document migration and compatibility rules
- create a handoff note
```

Expected package structure:

```text
packages/
├── creative-contracts/
├── asset-contracts/
├── media-contracts/
├── scene-contracts/
├── render-contracts/
└── brand-contracts/
```

After review:

```bash
git add .
git commit -m "feat: add marketing fabric shared contracts"
git push -u origin feat/marketing-contracts
```

Merge into:

```text
feat/marketing-production-fabric
```

---

# Step 4 — Create Git Worktrees

Create one worktree per active workstream.

```bash
mkdir -p ../arganta-worktrees
```

Example:

```bash
git worktree add ../arganta-worktrees/creative-core   -b feat/creative-core feat/marketing-production-fabric

git worktree add ../arganta-worktrees/asset-registry   -b feat/asset-registry feat/marketing-production-fabric

git worktree add ../arganta-worktrees/media-core   -b feat/media-core feat/marketing-production-fabric

git worktree add ../arganta-worktrees/brand-system   -b feat/brand-system feat/marketing-production-fabric

git worktree add ../arganta-worktrees/scene-system   -b feat/scene-system feat/marketing-production-fabric

git worktree add ../arganta-worktrees/render-engine   -b feat/render-engine feat/marketing-production-fabric

git worktree add ../arganta-worktrees/website-builder   -b feat/website-builder feat/marketing-production-fabric
```

Open a separate Claude Code session in each worktree.

---

# Step 5 — Launch the First Parallel Wave

Start these immediately:

| Workstream | Model |
|---|---|
| Creative Document Core | Opus |
| Asset Registry | Opus |
| Brand System | Opus |
| Media Core | Sonnet |
| 3D Scene System | Sonnet |
| Render Engine | Sonnet |
| Website Builder | Sonnet |

Other workstreams may start against mocks, but these form the most important first wave.

---

# Step 6 — Use One TDD Per Claude Code Session

For example, the Media Core session receives only:

```text
03-TDD-v2/Build/20260713-Build-Sonnet-MediaCore.md
03-TDD-v2/Contracts/20260713-Architecture-Opus-MediaJobContract.md
03-TDD-v2/Contracts/20260713-Architecture-Opus-AssetContract.md
```

Do not load every workstream file into the same context.

---

# Step 7 — Standard Claude Code Launch Prompt

Use this prompt for every workstream:

```text
You are the sole implementation owner of this workstream.

Read:
- the workstream TDD
- the shared contracts
- the relevant current Arganta repository paths

Rules:
- preserve GitHub, Supabase, and Vercel
- work only inside the owned paths
- do not modify another workstream's internals
- use mocks for unfinished dependencies
- depend only on shared contracts and documented adapters
- preserve offline development where relevant
- include tests, migrations, documentation, and a handoff note
- do not stop for minor ambiguity
- complete one end-to-end happy path before secondary features
```

---

# Step 8 — Force a Disciplined Execution Loop

## Phase A — Audit

Prompt:

```text
Audit the relevant repository paths.

Return:
1. current architecture
2. reusable code
3. gaps
4. proposed file tree
5. files to modify
6. public interfaces
7. Supabase changes
8. major risks

Do not edit yet.
```

## Phase B — Plan

Prompt:

```text
Create a detailed implementation plan.

Include:
- package structure
- public APIs
- persistence model
- migration strategy
- mocks
- tests
- failure handling
- rollback
- checkpoints

After the plan, begin scaffolding.
```

## Phase C — Happy Path

Require one complete vertical path.

Example for Media Core:

```text
request submitted
→ policy evaluated
→ mock provider selected
→ job persisted
→ output asset registered
→ realtime status updated
```

## Phase D — Failure Handling

Require:

- Validation
- Timeouts
- Retries
- Idempotency
- Cancellation where supported
- Normalized errors
- Audit logging

## Phase E — Tests

Minimum:

- Unit tests
- Contract tests
- Integration tests
- Migration checks
- One smoke test

## Phase F — Self-Review

Prompt:

```text
Review your implementation as a strict staff engineer.

Find:
- contract drift
- hidden coupling
- security problems
- missing Supabase RLS
- browser-exposed secrets
- provider lock-in
- Vercel runtime risks
- missing idempotency
- missing retries
- weak rollback
- untested failure modes

Fix all high and medium severity issues.
```

## Phase G — Handoff

Require:

```text
docs/handoffs/<workstream>.md
```

It must document:

- What changed
- Public APIs
- Environment variables
- Supabase migrations
- Tests
- Known limitations
- Integration steps
- Rollback steps

---

# Step 9 — Use Mocks to Preserve Parallelism

Examples:

## Website Builder

Use:

- Mock asset picker
- Mock scene component
- Mock publication service
- Fixture brand profile

## Presentation Builder

Use:

- Mock scene renderer
- Fixture narration asset
- Mock render request

## MCP Gateway

Use:

- Mock Media Core
- Mock Asset Registry
- Mock Campaign service

## Social Studio

Use:

- Fixture Creative Documents
- Mock render engine
- Fixture campaign data

## Campaign Studio

Use:

- Mock builder adapters
- Fixture cost estimates
- Mock approval service

A workstream should never wait for another workstream to finish before becoming testable.

---

# Step 10 — Fable Creative Review

Invoke Fable only after the milestone is functional.

Recommended checkpoints:

- First working website template
- First working 3D reactor
- First cinematic presentation
- First social pack
- First end-to-end campaign

Fable should review:

- Visual hierarchy
- Narrative
- Motion
- Lighting
- Camera
- Platform fit
- Brand consistency
- Wow effect

The original workstream owner applies the recommendations.

Do not transfer implementation ownership to Fable.

---

# Step 11 — Pull Request Standard

Every PR must include:

## Summary

What this workstream delivers.

## Owned Paths

Which folders were changed.

## Contract Changes

Any additive or breaking contract changes.

## Supabase Changes

- Migrations
- RLS
- Storage buckets
- Edge functions
- Realtime events

## Vercel Changes

- Routes
- Environment variables
- Runtime assumptions
- Preview behavior

## Evidence

- Test output
- Screenshots
- Video captures
- Demo steps

## Risk

- Security
- Cost
- Performance
- Migration
- Rollback

---

# Step 12 — Integration Testing

After each merge into the integration branch, run:

```bash
npm install
npm run type-check
npm run test
npm run build
```

Also run:

- Supabase migration validation
- RLS tests
- Contract compatibility tests
- Offline mode smoke test
- Vercel preview deployment
- HQ navigation smoke test

---

# Step 13 — First Vertical Slice

Do not wait for the whole platform.

Build this first:

```text
Campaign brief
→ reusable reactor scene
→ landing-page hero
→ 5-scene presentation
→ 16:9 launch video
→ 9:16 vertical video
→ Instagram post
→ Instagram story
→ asset lineage
→ cost and provider record
```

This proves the architecture across all important layers.

---

# Recommended Day-by-Day Strategy

## Day 1

- Add documentation package
- Create integration branch
- Build shared contracts
- Create worktrees

## Day 2–3

Start in parallel:

- Creative Document Core
- Asset Registry
- Brand System
- Media Core
- Scene System
- Render Engine
- Website Builder

## Day 4

- Contract review
- Supabase schema alignment
- First mock integrations
- First functional demos

## Day 5

- Fable review of website and 3D scene
- Apply recommendations
- Merge eligible foundational branches

## Week 2

- Presentation Builder
- Social Studio
- MCP Gateway
- Campaign Studio
- First complete vertical slice

## Week 3

- HQ Integration
- Approval and cost governance
- Provider health and job operations
- End-to-end integration hardening

---

# Critical Anti-Patterns

Never allow:

- Direct provider calls from React UI
- API keys in client bundles
- Builders importing private folders from other workstreams
- Generated assets without provenance
- Unversioned creative documents
- Browser-bound long-running render jobs
- Premium generation without maturity and budget policy
- Brand logic duplicated in each template
- MCP owning durable business state
- Fable directly editing implementation branches

---

# Final Operating Principle

Treat Claude Code sessions like independent engineering teams.

Each session receives:

- One TDD
- One owned folder set
- Shared contracts
- Mocks
- Acceptance criteria
- A branch
- A handoff requirement

This keeps work parallel, reviewable, and mergeable while preserving the existing Arganta stack.
