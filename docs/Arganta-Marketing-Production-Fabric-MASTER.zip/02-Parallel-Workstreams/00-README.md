# Arganta Parallel Workstreams

## Parallel Architecture
Architecture (Opus) and Build (Sonnet) streams run independently against stable interfaces.

Fable is used only as an optional creative review after implementation milestones.

Stack:
- GitHub
- Supabase
- Vercel

No workstream should directly depend on another workstream's implementation.
