---
workstream: WS05
title: Website Builder
strategic-lead: Fable
implementation-lead: Sonnet
priority: P1
---

# WS05 — Website Builder

## Mission

Create a Puck-based visual website builder using reusable Arganta React components and templates.

## End-to-End Scope

- Integrate Puck
- Build premium component registry and responsive controls
- Add asset picker, brand profiles, 3D scenes, animation settings, Supabase persistence, preview, and Vercel publication
- Create starter templates

## Deliverables

- `packages/builder-puck`
- `packages/website-components`
- `packages/website-templates`
- `HQ Website Studio`

## Recommended Model Ownership

### Opus
Own or review architecture, cross-workstream boundaries, governance, schema decisions, and maturation policy.

### Sonnet
Implement the complete workstream, including TypeScript, React, Supabase, tests, integration, and deployment.

### Fable
Fable. Use for visual direction, scene language, template quality, narrative, and wow-effect decisions where relevant.

## Dependencies

WS01, WS02, WS11, partial WS07

## Definition of Done

- The workstream is integrated through shared contracts rather than isolated code.
- Assets, jobs, costs, and provenance are persisted in Supabase.
- The implementation remains compatible with GitHub, Supabase, and Vercel.
- Tests and handoff documentation are included.

## End-to-End Handoff Prompt

Execute WS05 — Website Builder end to end inside the ArgantaLab monorepo. Preserve the existing GitHub-Supabase-Vercel stack. Reuse shared Arganta contracts, assets, brand profiles, maturity policies, and governance. Deliver implementation, tests, documentation, migrations where needed, and an integration summary.
