---
workstream: WS02
title: Asset Registry and Provenance
strategic-lead: Opus
implementation-lead: Sonnet
priority: P0
---

# WS02 — Asset Registry and Provenance

## Mission

Create one universal asset system shared across every HQ builder.

## End-to-End Scope

- Create media_assets and asset relation graph
- Track provider, model, prompt, seed, cost, rights, and approvals
- Implement Supabase Storage, signed URLs, thumbnails, proxies, search, tags, and deletion safety
- Create provenance and asset detail views

## Deliverables

- `Supabase migrations and RLS`
- `packages/asset-registry`
- `Asset lineage service`
- `Provenance UI`

## Recommended Model Ownership

### Opus
Own or review architecture, cross-workstream boundaries, governance, schema decisions, and maturation policy.

### Sonnet
Implement the complete workstream, including TypeScript, React, Supabase, tests, integration, and deployment.

### Fable
Fable consult/review. Use for visual direction, scene language, template quality, narrative, and wow-effect decisions where relevant.

## Dependencies

WS01

## Definition of Done

- The workstream is integrated through shared contracts rather than isolated code.
- Assets, jobs, costs, and provenance are persisted in Supabase.
- The implementation remains compatible with GitHub, Supabase, and Vercel.
- Tests and handoff documentation are included.

## End-to-End Handoff Prompt

Execute WS02 — Asset Registry and Provenance end to end inside the ArgantaLab monorepo. Preserve the existing GitHub-Supabase-Vercel stack. Reuse shared Arganta contracts, assets, brand profiles, maturity policies, and governance. Deliver implementation, tests, documentation, migrations where needed, and an integration summary.
