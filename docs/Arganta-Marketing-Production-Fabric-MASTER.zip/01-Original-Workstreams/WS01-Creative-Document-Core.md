---
workstream: WS01
title: Creative Document Core
strategic-lead: Opus
implementation-lead: Sonnet
priority: P0
---

# WS01 — Creative Document Core

## Mission

Create the shared document model used by websites, presentations, videos, social posts, campaigns, and reusable scenes.

## End-to-End Scope

- Define CreativeDocument and CreativeNode
- Support website, presentation, video, social, carousel, story, campaign, and scene types
- Define layout, style, animation, timeline, format, metadata, versioning, and migrations
- Create Zod schemas, JSON Schema exports, fixtures, and tests

## Deliverables

- `packages/creative-contracts`
- `Schema migration framework`
- `Fixtures and documentation`

## Recommended Model Ownership

### Opus
Own or review architecture, cross-workstream boundaries, governance, schema decisions, and maturation policy.

### Sonnet
Implement the complete workstream, including TypeScript, React, Supabase, tests, integration, and deployment.

### Fable
Fable consult/review. Use for visual direction, scene language, template quality, narrative, and wow-effect decisions where relevant.

## Dependencies

None

## Definition of Done

- The workstream is integrated through shared contracts rather than isolated code.
- Assets, jobs, costs, and provenance are persisted in Supabase.
- The implementation remains compatible with GitHub, Supabase, and Vercel.
- Tests and handoff documentation are included.

## End-to-End Handoff Prompt

Execute WS01 — Creative Document Core end to end inside the ArgantaLab monorepo. Preserve the existing GitHub-Supabase-Vercel stack. Reuse shared Arganta contracts, assets, brand profiles, maturity policies, and governance. Deliver implementation, tests, documentation, migrations where needed, and an integration summary.
