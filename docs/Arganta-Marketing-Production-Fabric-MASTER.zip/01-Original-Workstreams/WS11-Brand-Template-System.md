---
workstream: WS11
title: Brand and Template System
strategic-lead: Fable
implementation-lead: Sonnet
priority: P0
---

# WS11 — Brand and Template System

## Mission

Create reusable visual, motion, voice, sound, and template systems that keep all outputs consistent.

## End-to-End Scope

- Define Arganta master, HQ, KinetikCircle, ArgantaLabs, LashiraBloom, and product profiles
- Capture logos, colors, typography, spacing, imagery, 3D materials, lighting, motion, voice, sound, CTA rules, and forbidden treatments
- Create template registry, versioning, validation, starter packs, and preview gallery

## Deliverables

- `packages/brand-system`
- `packages/template-registry`
- `Brand profiles`
- `Template gallery`

## Recommended Model Ownership

### Opus
Own or review architecture, cross-workstream boundaries, governance, schema decisions, and maturation policy.

### Sonnet
Implement the complete workstream, including TypeScript, React, Supabase, tests, integration, and deployment.

### Fable
Fable. Use for visual direction, scene language, template quality, narrative, and wow-effect decisions where relevant.

## Dependencies

WS01

## Definition of Done

- The workstream is integrated through shared contracts rather than isolated code.
- Assets, jobs, costs, and provenance are persisted in Supabase.
- The implementation remains compatible with GitHub, Supabase, and Vercel.
- Tests and handoff documentation are included.

## End-to-End Handoff Prompt

Execute WS11 — Brand and Template System end to end inside the ArgantaLab monorepo. Preserve the existing GitHub-Supabase-Vercel stack. Reuse shared Arganta contracts, assets, brand profiles, maturity policies, and governance. Deliver implementation, tests, documentation, migrations where needed, and an integration summary.
