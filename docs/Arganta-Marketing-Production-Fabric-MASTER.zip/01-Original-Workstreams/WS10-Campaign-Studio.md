---
workstream: WS10
title: Campaign Studio
strategic-lead: Opus
implementation-lead: Sonnet
priority: P2
---

# WS10 — Campaign Studio

## Mission

Turn product strategy and narrative into coordinated websites, presentations, 3D scenes, videos, and social packs.

## End-to-End Scope

- Create campaign brief, objective, audience, message hierarchy, narrative, visual direction, asset plan, deliverable matrix, budget, approvals, and performance hooks
- Orchestrate templates, media generation, variants, reviews, and exports
- Create product launch, feature launch, founder narrative, partnership, world reveal, game launch, and educational recipes

## Deliverables

- `packages/campaign-core`
- `packages/campaign-templates`
- `HQ Campaign Studio`
- `Campaign recipes and cost estimator`

## Recommended Model Ownership

### Opus
Own or review architecture, cross-workstream boundaries, governance, schema decisions, and maturation policy.

### Sonnet
Implement the complete workstream, including TypeScript, React, Supabase, tests, integration, and deployment.

### Fable
Fable consult/review. Use for visual direction, scene language, template quality, narrative, and wow-effect decisions where relevant.

## Dependencies

WS01 through WS09 and WS11

## Definition of Done

- The workstream is integrated through shared contracts rather than isolated code.
- Assets, jobs, costs, and provenance are persisted in Supabase.
- The implementation remains compatible with GitHub, Supabase, and Vercel.
- Tests and handoff documentation are included.

## End-to-End Handoff Prompt

Execute WS10 — Campaign Studio end to end inside the ArgantaLab monorepo. Preserve the existing GitHub-Supabase-Vercel stack. Reuse shared Arganta contracts, assets, brand profiles, maturity policies, and governance. Deliver implementation, tests, documentation, migrations where needed, and an integration summary.
