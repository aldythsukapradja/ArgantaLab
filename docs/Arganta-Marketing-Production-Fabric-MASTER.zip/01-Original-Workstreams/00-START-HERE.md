---
title: Arganta Marketing Production Fabric
type: workstream-index
status: planning
owner: Aldyth Sukapradja
stack: [GitHub, Supabase, Vercel]
---

# Arganta Marketing Production Fabric

## Purpose

Build a reusable creative operating system that transforms product intelligence into websites, cinematic presentations, reusable 3D scenes, videos, social content, and campaign packs through one shared component, scene, asset, and rendering architecture.

## Foundation Principle

> Ideation should be free. Concept should be free. Prototype should be free to low cost. Development should be paid but cheap. Deployment should be cheap by default and expensive only when justified.

## Parallel Workstreams

| ID | Workstream | Primary Outcome | Recommended Lead |
|---|---|---|---|
| WS01 | Creative Document Core | Shared schema for all creative outputs | Opus |
| WS02 | Asset Registry & Provenance | Universal asset graph, lineage, rights, cost | Opus |
| WS03 | Media Core & Provider Router | Provider-agnostic media orchestration | Sonnet |
| WS04 | MCP Gateway | Thin agent-facing control layer | Sonnet |
| WS05 | Website Builder | Puck-based reusable website builder | Sonnet + Fable |
| WS06 | Presentation Builder | Cinematic scene-based HTML presentation system | Fable + Sonnet |
| WS07 | 3D Scene System | Reusable 3D components and timelines | Fable + Sonnet |
| WS08 | Render & Export Engine | Remotion, browser, FFmpeg output pipeline | Sonnet |
| WS09 | Social Studio | Instagram, TikTok, LinkedIn, Shorts outputs | Fable + Sonnet |
| WS10 | Campaign Studio | Narrative-to-campaign orchestration | Opus + Fable + Sonnet |
| WS11 | Brand & Template System | Brand profiles, templates, reusable recipes | Fable + Sonnet |
| WS12 | HQ Integration & Governance | Builder integration, approvals, budgets, maturity | Opus + Sonnet |

## Model Role Guidance

### Opus
Use for architecture decisions, cross-workstream coherence, data models, governance, maturation logic, cost policy, and difficult refactors.

### Sonnet
Use for TypeScript implementation, Supabase migrations, React components, MCP tools, provider adapters, tests, and Vercel integration.

### Fable
Use for creative direction, cinematic narrative, visual systems, website scenes, presentation flow, 3D art direction, social templates, and campaign concepts.

## Parallelization

### Wave 1
WS01, WS02, WS03, WS11

### Wave 2
WS04, WS05, WS07, WS08

### Wave 3
WS06, WS09

### Wave 4
WS10

### Wave 5
WS12

## First Vertical Slice

- One shared Creative Document
- One shared Asset ID
- One provider-agnostic image generation job
- One reusable 3D reactor scene
- One website page
- One cinematic presentation
- One 9:16 social video
- One campaign exported into multiple formats
