---
workstream: WS04
title: MCP Gateway
strategic-lead: Sonnet
implementation-lead: Sonnet
priority: P1
---

# WS04 — MCP Gateway

## Mission

Expose Arganta creative capabilities to Claude, Codex, ChatGPT, and HQ agents through a thin MCP layer.

## End-to-End Scope

- Use official MCP TypeScript SDK
- Expose media, asset, scene, website, presentation, campaign, social, render, and brand tools
- Propagate actor identity and enforce authentication
- Keep durable state and business logic outside MCP

## Deliverables

- `packages/mcp-gateway`
- `Vercel deployment`
- `Tool schemas`
- `Test client`

## Recommended Model Ownership

### Opus
Own or review architecture, cross-workstream boundaries, governance, schema decisions, and maturation policy.

### Sonnet
Implement the complete workstream, including TypeScript, React, Supabase, tests, integration, and deployment.

### Fable
Optional. Use for visual direction, scene language, template quality, narrative, and wow-effect decisions where relevant.

## Dependencies

WS01, WS02, WS03

## Definition of Done

- The workstream is integrated through shared contracts rather than isolated code.
- Assets, jobs, costs, and provenance are persisted in Supabase.
- The implementation remains compatible with GitHub, Supabase, and Vercel.
- Tests and handoff documentation are included.

## End-to-End Handoff Prompt

Execute WS04 — MCP Gateway end to end inside the ArgantaLab monorepo. Preserve the existing GitHub-Supabase-Vercel stack. Reuse shared Arganta contracts, assets, brand profiles, maturity policies, and governance. Deliver implementation, tests, documentation, migrations where needed, and an integration summary.
