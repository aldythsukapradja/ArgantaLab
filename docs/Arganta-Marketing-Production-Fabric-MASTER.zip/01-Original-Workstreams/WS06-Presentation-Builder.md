---
workstream: WS06
title: Cinematic Presentation Builder
strategic-lead: Fable
implementation-lead: Sonnet
priority: P2
---

# WS06 — Cinematic Presentation Builder

## Mission

Build a scene-based HTML presentation system that can also render to video and social formats.

## End-to-End Scope

- Create scene editor and player
- Support keyboard, touch, cinematic transitions, narration, 3D, GSAP, and Theatre.js
- Export HTML and hand off to video renderer
- Create Apple-style, founder-tour, architecture, partnership, investor, product, and world templates

## Deliverables

- `packages/presentation-core`
- `packages/presentation-components`
- `packages/presentation-templates`
- `HQ Presentation Studio`

## Recommended Model Ownership

### Opus
Own or review architecture, cross-workstream boundaries, governance, schema decisions, and maturation policy.

### Sonnet
Implement the complete workstream, including TypeScript, React, Supabase, tests, integration, and deployment.

### Fable
Fable. Use for visual direction, scene language, template quality, narrative, and wow-effect decisions where relevant.

## Dependencies

WS01, WS02, WS07, WS08, WS11

## Definition of Done

- The workstream is integrated through shared contracts rather than isolated code.
- Assets, jobs, costs, and provenance are persisted in Supabase.
- The implementation remains compatible with GitHub, Supabase, and Vercel.
- Tests and handoff documentation are included.

## End-to-End Handoff Prompt

Execute WS06 — Cinematic Presentation Builder end to end inside the ArgantaLab monorepo. Preserve the existing GitHub-Supabase-Vercel stack. Reuse shared Arganta contracts, assets, brand profiles, maturity policies, and governance. Deliver implementation, tests, documentation, migrations where needed, and an integration summary.
