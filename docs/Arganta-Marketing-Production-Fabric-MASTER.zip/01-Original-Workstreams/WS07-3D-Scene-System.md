---
workstream: WS07
title: Reusable 3D Scene System
strategic-lead: Fable
implementation-lead: Sonnet
priority: P1
---

# WS07 — Reusable 3D Scene System

## Mission

Create data-driven 3D components and scenes reusable in HQ, websites, presentations, video, and social media.

## End-to-End Scope

- Use React Three Fiber, Drei, Theatre.js, GSAP, and postprocessing
- Build reactor, orbital system, product constellation, particle field, data globe, portal, hologram card, device frame, rigs, and environments
- Support serialization, parameter controls, preview, embedding, Remotion rendering, thumbnails, and performance tiers

## Deliverables

- `packages/scene-contracts`
- `packages/scene-components`
- `packages/scene-r3f`
- `packages/scene-theatre`
- `HQ 3D Scene Studio`

## Recommended Model Ownership

### Opus
Own or review architecture, cross-workstream boundaries, governance, schema decisions, and maturation policy.

### Sonnet
Implement the complete workstream, including TypeScript, React, Supabase, tests, integration, and deployment.

### Fable
Fable. Use for visual direction, scene language, template quality, narrative, and wow-effect decisions where relevant.

## Dependencies

WS01, WS02, WS11

## Definition of Done

- The workstream is integrated through shared contracts rather than isolated code.
- Assets, jobs, costs, and provenance are persisted in Supabase.
- The implementation remains compatible with GitHub, Supabase, and Vercel.
- Tests and handoff documentation are included.

## End-to-End Handoff Prompt

Execute WS07 — Reusable 3D Scene System end to end inside the ArgantaLab monorepo. Preserve the existing GitHub-Supabase-Vercel stack. Reuse shared Arganta contracts, assets, brand profiles, maturity policies, and governance. Deliver implementation, tests, documentation, migrations where needed, and an integration summary.
