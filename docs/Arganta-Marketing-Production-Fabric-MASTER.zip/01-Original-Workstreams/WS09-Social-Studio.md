---
workstream: WS09
title: Social Studio
strategic-lead: Fable
implementation-lead: Sonnet
priority: P2
---

# WS09 — Social Studio

## Mission

Create a multi-format studio for Instagram, TikTok, YouTube Shorts, LinkedIn, X, Product Hunt, and app-store assets.

## End-to-End Scope

- Implement master-content adaptation rather than simple cropping
- Add safe zones, subtitles, carousel editing, vertical-video templates, thumbnails, brand validation, export packs, approvals, and versioning
- Create launch, feature, founder, before-after, data, character, world, education, tutorial, countdown, and partnership templates

## Deliverables

- `packages/social-formats`
- `packages/social-templates`
- `HQ Social Studio`
- `Export pack generator`

## Recommended Model Ownership

### Opus
Own or review architecture, cross-workstream boundaries, governance, schema decisions, and maturation policy.

### Sonnet
Implement the complete workstream, including TypeScript, React, Supabase, tests, integration, and deployment.

### Fable
Fable. Use for visual direction, scene language, template quality, narrative, and wow-effect decisions where relevant.

## Dependencies

WS01, WS02, WS08, WS11

## Definition of Done

- The workstream is integrated through shared contracts rather than isolated code.
- Assets, jobs, costs, and provenance are persisted in Supabase.
- The implementation remains compatible with GitHub, Supabase, and Vercel.
- Tests and handoff documentation are included.

## End-to-End Handoff Prompt

Execute WS09 — Social Studio end to end inside the ArgantaLab monorepo. Preserve the existing GitHub-Supabase-Vercel stack. Reuse shared Arganta contracts, assets, brand profiles, maturity policies, and governance. Deliver implementation, tests, documentation, migrations where needed, and an integration summary.
