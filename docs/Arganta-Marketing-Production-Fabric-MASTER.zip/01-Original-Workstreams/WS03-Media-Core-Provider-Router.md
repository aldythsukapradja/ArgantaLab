---
workstream: WS03
title: Media Core and Provider Router
strategic-lead: Sonnet
implementation-lead: Sonnet
priority: P0
---

# WS03 — Media Core and Provider Router

## Mission

Create provider-agnostic orchestration for image, video, voice, music, SFX, avatars, and transformations.

## End-to-End Scope

- Define provider adapter interface and capability registry
- Implement cost estimates, maturity-aware routing, fallbacks, retries, budgets, and approvals
- Add mock provider and first real adapters
- Normalize asynchronous jobs and webhooks

## Deliverables

- `packages/media-core`
- `packages/media-providers`
- `Routing policy engine`
- `Cost and job services`

## Recommended Model Ownership

### Opus
Own or review architecture, cross-workstream boundaries, governance, schema decisions, and maturation policy.

### Sonnet
Implement the complete workstream, including TypeScript, React, Supabase, tests, integration, and deployment.

### Fable
Optional. Use for visual direction, scene language, template quality, narrative, and wow-effect decisions where relevant.

## Dependencies

WS01, WS02

## Definition of Done

- The workstream is integrated through shared contracts rather than isolated code.
- Assets, jobs, costs, and provenance are persisted in Supabase.
- The implementation remains compatible with GitHub, Supabase, and Vercel.
- Tests and handoff documentation are included.

## End-to-End Handoff Prompt

Execute WS03 — Media Core and Provider Router end to end inside the ArgantaLab monorepo. Preserve the existing GitHub-Supabase-Vercel stack. Reuse shared Arganta contracts, assets, brand profiles, maturity policies, and governance. Deliver implementation, tests, documentation, migrations where needed, and an integration summary.
