---
workstream: WS08
title: Render and Export Engine
strategic-lead: Sonnet
implementation-lead: Sonnet
priority: P1
---

# WS08 — Render and Export Engine

## Mission

Create one rendering layer for browser preview, deterministic video, social formats, thumbnails, and final exports.

## End-to-End Scope

- Use existing @arganta/video, Remotion, FFmpeg, Sharp, Canvas, and WebCodecs where practical
- Implement asynchronous render jobs, progress, retries, audio mixing, subtitles, proxy creation, and asset registration
- Support 16:9, 9:16, 1:1, 4:5, presentation, carousel, story, thumbnail, and app-store presets

## Deliverables

- `packages/render-core`
- `packages/render-remotion`
- `packages/render-browser`
- `packages/render-ffmpeg`
- `Supabase render jobs`

## Recommended Model Ownership

### Opus
Own or review architecture, cross-workstream boundaries, governance, schema decisions, and maturation policy.

### Sonnet
Implement the complete workstream, including TypeScript, React, Supabase, tests, integration, and deployment.

### Fable
Fable consult/review. Use for visual direction, scene language, template quality, narrative, and wow-effect decisions where relevant.

## Dependencies

WS01, WS02, WS03, WS07

## Definition of Done

- The workstream is integrated through shared contracts rather than isolated code.
- Assets, jobs, costs, and provenance are persisted in Supabase.
- The implementation remains compatible with GitHub, Supabase, and Vercel.
- Tests and handoff documentation are included.

## End-to-End Handoff Prompt

Execute WS08 — Render and Export Engine end to end inside the ArgantaLab monorepo. Preserve the existing GitHub-Supabase-Vercel stack. Reuse shared Arganta contracts, assets, brand profiles, maturity policies, and governance. Deliver implementation, tests, documentation, migrations where needed, and an integration summary.
