---
title: Model Delegation Matrix
type: execution-guide
---

# Model Delegation Matrix

| Workstream | Strategic Lead | Implementation Lead | Creative Lead |
|---|---|---|---|
| WS01 Creative Document Core | Opus | Sonnet | Fable consult |
| WS02 Asset Registry | Opus | Sonnet | Fable consult |
| WS03 Media Core | Opus review | Sonnet | Fable consult |
| WS04 MCP Gateway | Opus review | Sonnet | Not required |
| WS05 Website Builder | Opus review | Sonnet | Fable |
| WS06 Presentation Builder | Opus review | Sonnet | Fable |
| WS07 3D Scene System | Opus review | Sonnet | Fable |
| WS08 Render Engine | Opus review | Sonnet | Fable consult |
| WS09 Social Studio | Opus review | Sonnet | Fable |
| WS10 Campaign Studio | Opus | Sonnet | Fable |
| WS11 Brand System | Opus review | Sonnet | Fable |
| WS12 HQ Governance | Opus | Sonnet | Fable review |

## Assignment Rules

Use Opus when a decision affects multiple packages, schema migrations, governance, cost policy, or product boundaries.

Use Sonnet for scoped end-to-end implementation, Supabase wiring, React interfaces, provider adapters, tests, and deployment.

Use Fable for visual language, cinematic scenes, templates, social content systems, campaign concepts, and wow-effect review.
