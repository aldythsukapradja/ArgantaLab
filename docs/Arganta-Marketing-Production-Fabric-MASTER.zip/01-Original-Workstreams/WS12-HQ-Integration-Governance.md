---
workstream: WS12
title: HQ Integration and Governance
strategic-lead: Opus
implementation-lead: Sonnet
priority: P3
---

# WS12 — HQ Integration and Governance

## Mission

Integrate all workstreams into HQ and enforce maturity, cost, approvals, provenance, and operational control.

## End-to-End Scope

- Create shared asset picker, universal job tray, approval queue, cost dashboard, provider health, maturity controls, publication readiness, audit trail, and role permissions
- Integrate Campaign, Website, Presentation, 3D Scene, Social, Template, Brand, and Media Operations surfaces
- Preserve offline and mock mode
- Ensure no builder bypasses Media Core or governance

## Deliverables

- `HQ navigation and builder shell`
- `Governance workflows`
- `Cost and provider dashboard`
- `Operational playbook`

## Recommended Model Ownership

### Opus
Own or review architecture, cross-workstream boundaries, governance, schema decisions, and maturation policy.

### Sonnet
Implement the complete workstream, including TypeScript, React, Supabase, tests, integration, and deployment.

### Fable
Fable consult/review. Use for visual direction, scene language, template quality, narrative, and wow-effect decisions where relevant.

## Dependencies

All workstreams

## Definition of Done

- The workstream is integrated through shared contracts rather than isolated code.
- Assets, jobs, costs, and provenance are persisted in Supabase.
- The implementation remains compatible with GitHub, Supabase, and Vercel.
- Tests and handoff documentation are included.

## End-to-End Handoff Prompt

Execute WS12 — HQ Integration and Governance end to end inside the ArgantaLab monorepo. Preserve the existing GitHub-Supabase-Vercel stack. Reuse shared Arganta contracts, assets, brand profiles, maturity policies, and governance. Deliver implementation, tests, documentation, migrations where needed, and an integration summary.
