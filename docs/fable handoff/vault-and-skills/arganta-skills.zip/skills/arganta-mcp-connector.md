---
name: arganta-mcp-connector
description: Use when wiring a new MCP connector into the Bridge server (Render) or Supabase backend. Encodes the actual auth pattern and registration steps already in use.
---

# Arganta MCP Connector

## When this triggers
- Adding or debugging an MCP connector for Circle HQ / the Bridge server

## What to do
1. Follow the existing Bridge server auth and registration pattern — don't invent a new one per connector.
2. Register the new connector's tools against the product ontology graph (give it a `ladders_to` target) so it isn't an orphan capability.
3. Test against `office_report` / `graph_query` to confirm the new connector's data shows up with the right provenance badge.

## Knowledge graph link
`ladders_to: arch.sdk` (Technology, "Circle SDK", currently amber/partial) — every new connector should move this toward live, not just add surface area.
