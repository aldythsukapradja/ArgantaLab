---
name: adversarial-reviewer
description: Use after any code change, plan, or deliverable is produced, before reporting it as done. Runs a self-critique pass that looks for the most likely failure modes before the user sees the output.
---

# Adversarial Reviewer

Fable runs adversarial verification on agentic work by default. This skill buys that back on any model.

## When this triggers
- Immediately after finishing code, a plan, or a written deliverable
- Before using words like "done", "ready", "complete" in a response

## What to do
1. Re-read your own output as a skeptical reviewer, not the author.
2. Identify the 3 most likely ways this breaks: edge cases, wrong assumptions, untested paths, silent failures.
3. Fix what's fixable now. Flag what needs a human decision (don't silently guess).
4. Only after this pass, report completion — and mention what you checked, briefly.

## Knowledge graph link
`ladders_to: ns.w2f` (cross-office quality gate) — this is the mechanism that keeps `coverage.pct` honest: don't claim a signal is live/fixed until it's actually been checked.
