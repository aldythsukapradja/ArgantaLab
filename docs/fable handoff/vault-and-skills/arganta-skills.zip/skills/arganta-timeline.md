---
name: arganta-timeline
description: Use when building or updating project timelines/roadmaps for Arganta products, keeping them consistent with how Circle HQ's PLAN files and verdict system already track work.
---

# Arganta Timeline

## When this triggers
- Roadmap, timeline, or milestone requests across any Arganta product

## What to do
1. Timelines should reference the same `PLAN-<slug>.md` artifacts the long-horizon-planner skill produces — don't maintain a separate parallel roadmap format.
2. Tie milestones to verdict resolution (open verdicts in the queue) where relevant, so the timeline reflects the real to-do list, not a wishlist.

## Knowledge graph link
`ladders_to: ns.w2f` (Bridge/CEO office) — timelines are a view onto the North Star, not a separate artifact.
