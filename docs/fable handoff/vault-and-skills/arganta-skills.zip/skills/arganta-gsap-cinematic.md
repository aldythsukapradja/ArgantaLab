---
name: arganta-gsap-cinematic
description: Use for GSAP animation and cinematic sequencing work — page-load films, HUD reveals, scroll-triggered moments — matching the existing COSMO_GENESIS-style opener conventions.
---

# Arganta GSAP Cinematic

## When this triggers
- Any animated sequence, cinematic opener, or scroll-triggered reveal for the Arganta/Circle HQ family

## What to do
1. Reuse the existing sequencing patterns from prior builds (COSMO_GENESIS, RMO Cosmo skins) rather than starting from generic GSAP tutorials.
2. Favor one orchestrated moment over scattered micro-animations.
3. Respect `prefers-reduced-motion` even in cinematic builds.

## Knowledge graph link
`ladders_to: hq.builders` (Technology) — same artifact-quality lever as the design system skill.
