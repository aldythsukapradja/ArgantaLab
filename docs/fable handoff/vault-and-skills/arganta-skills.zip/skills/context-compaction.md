---
name: context-compaction
description: Use in long sessions approaching context limits, or any multi-day project. Periodically harvests session state into the Obsidian second brain instead of letting context silently degrade.
---

# Context Compaction

## When this triggers
- Sessions running long, or the conversation is clearly multi-day
- Before starting a new session on a project that has prior context elsewhere

## What to do
1. Summarize: decided facts, open threads, next steps.
2. Write the summary into `/projects/<project>.md` or `/wiki` per the second-brain convention (inbox → projects → output → wiki; wiki is only written from finished output, never directly).
3. Start the next session from the summary, not from re-reading the full history.
4. Use the `/harvest` command if it exists in the vault to promote finished project state into wiki.

## Knowledge graph link
`ladders_to: hq.data` (Technology office, "Tables mapped") — this is what keeps state addressable instead of trapped in chat history.
