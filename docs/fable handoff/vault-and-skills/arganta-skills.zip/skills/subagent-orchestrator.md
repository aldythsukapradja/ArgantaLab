---
name: subagent-orchestrator
description: Use for large tasks that need research, implementation, and verification as distinct phases — the "ultracode" pattern. Splits work across Task-tool subagents instead of one linear pass.
---

# Subagent Orchestrator

## When this triggers
- Tasks explicitly framed as big/broad, or requiring research + build + verify
- Anything that would have been run as a single "ultracode" prompt on Fable

## What to do
1. Split into three roles:
   - **Research subagent** — gathers context, reads the codebase/docs, surfaces constraints
   - **Implementation subagent** — makes the change based on research output
   - **Verification subagent** — tests, adversarially reviews, checks acceptance criteria
2. Run each via the Task tool as a separate subagent call.
3. Synthesize results into one final report — don't just concatenate subagent outputs.
4. Don't stop to ask permission on reversible steps; do stop for irreversible ones (deletes, deploys, payments).

## Knowledge graph link
`ladders_to: hq.builders` (Technology office, "Artifacts built") — this is the mechanism, not just the plan, that ships PLAN-<slug>.md files into real artifacts.
