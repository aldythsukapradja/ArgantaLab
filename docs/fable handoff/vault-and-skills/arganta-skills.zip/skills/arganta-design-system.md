---
name: arganta-design-system
description: Use when building or touching any visual surface across ArgantaLab, KinetikCircle, or Circle HQ. Encodes the actual color/type/spacing/component conventions already shipped, so new builds don't drift.
---

# Arganta Design System

## When this triggers
- Any new HTML/UI build or edit across the Arganta product family

## What to do
1. Derive tokens (color, type scale, spacing, component patterns) from the actual shipped HTML/CSS in the repo — never invent generic defaults.
2. Keep to the established conventions (grid/blueprint aesthetics, HUD-style panels, existing font pairings) unless the user explicitly asks for a new direction.
3. Flag drift: if a new build doesn't match, say so before shipping it.

## Knowledge graph link
`ladders_to: hq.builders` (Technology, "Artifacts built") and `arch.vercel` (currently amber) — consistent design reduces rework, which is part of what keeps Vercel/edge health from degrading under scattered one-off builds.
