---
name: arganta-workflow
description: Use to keep the end-to-end Arganta build workflow consistent — idea to single-HTML prototype to Circle HQ registration to instrumentation — instead of ad hoc builds.
---

# Arganta Workflow

## When this triggers
- Starting any new Arganta build, from idea stage

## What to do
1. Follow the standing pipeline: idea → single-HTML prototype → register the artifact against the ontology graph (give it a node/owner) → wire instrumentation before calling it shipped.
2. Never skip the instrumentation step — this is exactly how signals end up `placeholder`/blind in the graph.

## Knowledge graph link
`ladders_to: ns.w2f` via `hq.builders` — this skill is the connective tissue that stops "shipped" from silently meaning "not measured".
