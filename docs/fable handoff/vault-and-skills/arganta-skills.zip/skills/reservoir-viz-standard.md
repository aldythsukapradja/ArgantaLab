---
name: reservoir-viz-standard
description: Use for any chart of reservoir data — pressure, VRR, welltest, pattern maps. Enforces a fixed style matching the LUMEN Power BI training studio conventions instead of library defaults.
---

# Reservoir Viz Standard

## When this triggers
- Any chart request involving Al Shaheen reservoir data

## What to do
1. Use matplotlib/plotly with a fixed style sheet: colors, fonts, layout matching LUMEN's Power BI conventions.
2. Never fall back to library defaults for this data — inconsistency here reads as unpolished to NOC leadership audiences.
3. Keep annotation conventions consistent (pattern labels, aquifer gradient callouts, etc.) across charts.

## Knowledge graph link
External to the W2F ontology — reservoir-domain tooling, kept alongside the Arganta skills for a consistent daily-driver setup.
