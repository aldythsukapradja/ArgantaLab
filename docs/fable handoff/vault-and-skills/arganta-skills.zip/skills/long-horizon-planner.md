---
name: long-horizon-planner
description: Use before any task that touches 3+ files, spans multiple sessions, or is described as "the whole thing" / "big" / "end to end". Forces a written plan with acceptance criteria before implementation starts, so a less capable model can execute it without asking questions.
---

# Long-Horizon Planner

Fable's edge on big tasks isn't raw intelligence — it's that it plans deeper before acting. This skill recovers that behavior on Opus/Sonnet deliberately.

## When this triggers
- Any task spanning 3+ files or multiple work sessions
- Requests framed as "the whole project", "end to end", "everything"
- Before handing work off to a cheaper model (Sonnet) for execution

## What to do
1. Do NOT write implementation code yet.
2. Read the relevant codebase / context fully first.
3. Write `PLAN-<slug>.md` containing:
   - Goal (one sentence)
   - Exact files to touch
   - Step-by-step order
   - Edge cases a weaker pass would miss
   - Acceptance criteria the user can verify themselves
4. Rank multiple plans by leverage if more than one exists.
5. Only start implementation after the plan is written and (if high-stakes) confirmed.

## Knowledge graph link
`ladders_to: ns.w2f` via `lever.efficiency` (Technology office) — every plan this skill produces should reduce time-to-shipped, which is the activation lever currently weakest in the graph.
