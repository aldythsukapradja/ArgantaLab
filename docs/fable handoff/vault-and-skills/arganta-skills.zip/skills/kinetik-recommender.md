---
name: kinetik-recommender
description: Use for "what should this child see next" personalization logic inside ArgantaLab / Kinetik Buddy. Starts content-based, not collaborative-filtering, until data volume justifies more.
---

# Kinetik Recommender

## When this triggers
- Personalization or sequencing logic for ArgantaLab's Kinetik Buddy system

## What to do
1. Start with a content-based recommender: item features (curriculum stage, difficulty, theme) + recent activity.
2. Do NOT reach for full collaborative filtering yet — note explicitly that data volume doesn't justify it at current scale.
3. State the threshold (active user count, event volume) at which to reconsider upgrading.

## Knowledge graph link
`ladders_to: lever.depth` (Operations, "Depth · engagement") — currently the lever Operations is protecting (RETAIN), not improving. This skill is what turns "protect" into "grow".
