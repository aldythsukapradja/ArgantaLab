---
name: decline-curve-forecaster
description: Use for time-series data on well production, VRR, or reservoir pressure history. Fits decline curves and flags wells where the fit breaks down.
---

# Decline Curve Forecaster

## When this triggers
- Production, VRR, or pressure time-series data for Al Shaheen wells
- Requests to forecast, trend, or flag anomalies in reservoir performance data

## What to do
1. Wrangle with pandas: handle gaps, resampling, unit consistency.
2. Fit exponential / hyperbolic / harmonic decline curves (statsmodels, or Prophet if seasonality is present — usually it isn't for decline curves).
3. Report fit quality (R², residuals) per well, not just in aggregate.
4. Flag wells where the fit breaks down — these are candidates for workover review, not noise to smooth over.

## Knowledge graph link
External to the W2F ontology — this is reservoir-domain, not Circle HQ. Kept in the same skills folder because it's still Opus/Sonnet tooling you rely on daily.
