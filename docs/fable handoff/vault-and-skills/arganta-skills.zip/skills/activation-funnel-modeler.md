---
name: activation-funnel-modeler
description: Use when analyzing signup-to-active conversion or CAC data for ArgantaLab. Builds a classification model on activation and reports which funnel step to fix first.
---

# Activation Funnel Modeler

## When this triggers
- Any request touching signup→active conversion, CAC, or activation rate
- Directly relevant while `lever.efficiency` is flagged amber and CAC/payer is $75 at 2% conversion

## What to do
1. Wrangle funnel event data with pandas.
2. Fit a classification model (scikit-learn or xgboost) predicting activation.
3. Report feature importance — the point is finding *which step* to fix, not restating the aggregate conversion rate.
4. Cross-check against the `sig.difficulty_mismatch` handoff from Technology to Operations — content difficulty may be a confound.

## Knowledge graph link
`ladders_to: lever.efficiency` (Technology, currently the weakest lever in the graph) — this skill exists specifically to close that gap.
