# Roadmap Tracker

> Live status of the Fable-class initiatives. This is META-WORK state — kept separate from graph
> nodes (initiatives aren't product ontology). Cross-linked to nodes, not living inside them.

## Legend
- Status: `not-started` / `fable-in-progress` / `verified` / `handed-to-opus`
- Owner: which model does the work ([[model-ladder]] discipline)
- Verify: ⬜ claimed-done vs ✅ adversarially-verified (the honesty column)

| Initiative | Status | Owner | ladders_to | Before → After | Verify |
|---|---|---|---|---|---|
| Recon + Part A++ (wire blind signals) | not-started | Fable | lever.efficiency, coverage.pct | 11+ blind → 0 | ⬜ |
| Persona Core | not-started | Fable | (cross-cutting) | none → [[persona-core]] exists | ⬜ |
| Orchestration Spec (Layer 3) | not-started | Fable | hq.* routing | dashboard → router | ⬜ |
| Media Pipeline | not-started | Fable→Opus | hq.builders | concept → runnable chain | ⬜ |
| Vector DB / agent layer | not-started | Opus | (agent layer) | none → semantic recall | ⬜ |

## The honesty tension
"Live tracking" here = live relative to my check-ins, NOT real-time telemetry from inside
Fable's autonomous runs. Don't oversell it as more real-time than it is.

## Links
- Initiatives detail: [[fable-initiatives]]
- Owner logic: [[model-ladder]] · Serves: [[persona-core]]
