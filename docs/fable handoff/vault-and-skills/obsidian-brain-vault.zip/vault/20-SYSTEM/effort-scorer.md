# Effort Scorer

> Pre-flight triage. Score a task BEFORE running so I never over/under-provision a model.
> A Rail (deterministic thresholds) authored once, ridden by any Reasoner. Still to build as a skill.

## The axes
- **Ambiguity** — fully specified, or must the model decide what to do? (Resists scaffolding →
  pushes UP hardest.)
- **Horizon** — one turn, or hours across many tool calls?
- **Reversibility / stakes** — undoable cheaply, or hits prod/money/a client?
- **Context volume** — fits comfortably, or needs big window + compaction?
- **Verification cost** — if wrong, how expensive to catch?

## The output
Not "use model X" — but "use model X AND here's the scaffolding to make it perform like X+1."
E.g. "Sonnet-executable IF given a plan; Opus if not." That conditional is the product.

## The one-question shortcut (for the daily loop)
Frame-inventing or frame-filling? Inventing → Opus/Fable. Filling → Sonnet/Haiku.

## Links
- Feeds: [[daily-loop#Midday — Route]]
- Built on: [[model-ladder]]
- [[TO FILL: Fable — propose actual threshold values calibrated to my real task types]]
