# Skills Index

> Procedural memory — "what to do when." Each skill is a Rail: deterministic once authored.
> Every skill ladders to a graph node (no orphan skills). Full detail in [[knowledge-graph-map]].

## Agentic (Opus-parity)
- **long-horizon-planner** → PLAN-<slug>.md before code. ladders_to lever.efficiency
- **adversarial-reviewer** → self-critique before "done." Cross-office gate.
- **subagent-orchestrator** → research/impl/verify subagents. The "ultracode" pattern.
- **context-compaction** → harvest session state to vault. ladders_to hq.data

## ML / domain
- **decline-curve-forecaster** — well production/VRR forecasting (reservoir, external to W2F)
- **activation-funnel-modeler** → the $75 CAC / 2% conversion problem. ladders_to lever.efficiency
- **kinetik-recommender** → Kinetik Buddy personalization. ladders_to lever.depth
- **reservoir-viz-standard** — LUMEN/Power BI chart style (reservoir)

## Arganta product
- **arganta-design-system** → hq.builders + arch.vercel
- **arganta-gsap-cinematic** → hq.builders
- **arganta-mcp-connector** → arch.sdk
- **arganta-timeline** → ns.w2f
- **arganta-workflow** → ns.w2f via hq.builders

## Still to write
- **instrumentation-wiring** — owns the blind signals (see [[sensor-plan]])
- **effort-scorer** — see [[effort-scorer]]
- **persona-core-integration** — wires [[persona-core]] into the C-suite

## Links
- Indexed against: [[knowledge-graph-map]]
- Live location: `.claude/skills/`
