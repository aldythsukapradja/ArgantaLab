# KinetikCircle

> Family coordination OS. Part of the [[mental-model|UI/UX layer]].

## What it is
- Family OS: Today, Calendar, Moments, mini-apps, Circles/Connections/Friends. #known
- For my family — Kinara, Abdil, Keyla. #known

## Current state
- Core is live/green in the graph (RETAIN-flagged). #known
- Blind: calendar_open_no_add (parent-hook signal). #known

## Open threads
- [[TO FILL: Fable — confirm mini-app batch state]]

## Links
- Measured by: [[sensor-plan]]
