# Circle HQ

> Founder OS — the [[mental-model|Agent layer]] itself. My "super agent."

## What it is
- 25-agent C-suite architecture. Live Bridge MCP server on Render + Supabase. #known
- Exposes a product ontology graph: CEO brief, six office reports, node queries, verdict queue. #known
- Bridge URL: circle-hq-bridge.onrender.com/mcp #known

## The promotion (roadmap)
- Currently a dashboard I QUERY. The vision: promote it to a ROUTER that ACTS —
  score → pick model → load skills → call connectors → ladder to node → run + verify. #known
- The six offices become routing paths. See [[roadmap-tracker]].

## Persona integration
- The CEO/Bridge agent should reason using [[persona-core]], not generic "helpful agent" behavior.

## Open threads
- [[TO FILL: Fable — the Layer-3 orchestration spec is the biggest open design]]

## Links
- Consumes: [[persona-core]] · [[skills-index]] · [[mcp-connectors]]
- Tracked in: [[roadmap-tracker]]
