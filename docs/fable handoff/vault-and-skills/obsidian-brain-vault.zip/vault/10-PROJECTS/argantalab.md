# ArgantaLab

> Gamified children's learning. Part of the [[mental-model|UI/UX layer]].

## What it is
- Cambridge Primary curriculum, Duolingo-style mechanics, "Kinetik Buddy" pet system. #known
- Repo: github.com/aldythsukapradja/ArgantaLab #known
- Learn subtabs: NumberDash, WordQuest, WonderLab, LogicLand, WorldTrail, LifeQuest. #known

## Current state (from the graph)
- Weakest lever: activation/efficiency. Landing page fully blind. #known
- See [[sensor-plan]] for the full blind-signal list.

## Open threads
- [[TO FILL: Fable — pull latest from repo + Operations office_report]]

## Links
- Measured by: [[sensor-plan]] · [[coverage-tracker]]
- Design: [[skills-index#arganta-design-system]]
