# Followups (for Opus/Sonnet after Fable)

> Anything Fable couldn't finish. Written so a cheaper model continues with zero re-discovery.

- [[TO FILL: Fable — list unfinished items with exact files, next steps, acceptance criteria]]

## Links
- Roadmap: [[roadmap-tracker]]
