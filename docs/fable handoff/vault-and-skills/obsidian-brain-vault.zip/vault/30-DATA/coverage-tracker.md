# Coverage Tracker

> The one honest number. Watch this week over week.

## Current (last pull)
- **coverage.pct = 78%** — 59/76 nodes grounded (35 live, 24 partial, 3 simulated, 14 placeholder). #known
- Source: Circle HQ `ceo_brief`.

## Target
- 95%+. Everything in [[sensor-plan]] Tier 1 + Tier 2 moves this number.

## How to use
- Re-pull after each wiring batch. This is the before/after for the whole system in one number.
- If a week's work didn't move it, that work was vanity progress (see [[daily-loop#Weekly — Verify]]).

## Log
| Date | coverage.pct | note |
|---|---|---|
| [[TO FILL]] | 78% | baseline |

## Links
- Fed by: [[sensor-plan]] · Watched in: [[daily-loop]]
