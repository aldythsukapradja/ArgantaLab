# Knowledge Graph Map

> Reverse index: the graph's view of the skills. Keep in sync with [[skills-index]].
> Rule: no orphan skills. Every skill carries a ladders_to line.

| Skill | ladders_to | Office | Health |
|---|---|---|---|
| long-horizon-planner | ns.w2f via lever.efficiency | Technology | amber |
| adversarial-reviewer | ns.w2f (gate) | Bridge | amber |
| subagent-orchestrator | hq.builders | Technology | amber |
| context-compaction | hq.data | Technology | green |
| activation-funnel-modeler | lever.efficiency | Technology | amber (weakest lever) |
| kinetik-recommender | lever.depth | Operations | green |
| arganta-design-system | hq.builders + arch.vercel | Technology | amber |
| arganta-gsap-cinematic | hq.builders | Technology | amber |
| arganta-mcp-connector | arch.sdk | Technology | amber |
| arganta-timeline | ns.w2f | Bridge | amber |
| arganta-workflow | ns.w2f via hq.builders | Technology | amber |
| decline-curve-forecaster | (external — reservoir) | — | — |
| reservoir-viz-standard | (external — reservoir) | — | — |

## Blind nodes with no skill yet → the next skill to write
sig.dead_end_quit, sig.build_abandoned, sig.broken_share_link, sig.calendar_open_no_add,
sig.ugc_flagged, + the Landing page nodes. → **instrumentation-wiring** skill.

## Links
- Skills: [[skills-index]] · Blind list detail: [[sensor-plan]]
