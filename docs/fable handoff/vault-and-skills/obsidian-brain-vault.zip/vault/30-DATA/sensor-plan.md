# Sensor Plan

> What's measured, what's blind. A sensor with no consumer is just a log file — see the loop below.
> Pulled from Circle HQ. Respect provenance: simulated ≠ live.

## Tier 1 — BLIND (wire first, zero data)
- **Technology**: dead_end_quit, build_abandoned, broken_share_link, calendar_open_no_add
- **Operations**: arganta.home, ship.discover, land.home, land.products, land.pitch, sig.deck_no_waitlist
- **Legal**: sig.ugc_flagged
- (Fable: pull legal + treasury office_report to confirm the FULL list — may be >11.)

## Tier 2 — PARTIAL (tighten amber→live)
build.wizard/lab/pitch funnel, ship.library/gamestore attribution, arch.vercel, arch.sdk,
lever.breadth (k-factor — this is a FIX not an instrument).

## Tier 3 — LIVE (protect, don't break)
lever.depth/frequency, all Learn subtabs, KinetikCircle core, Fame/leaderboards.

## The loop (why sensors matter)
event fires → Supabase → Circle HQ ingests → node provenance updates → verdict opens if bad →
skill acts on verdict. Three of four steps already built. Missing piece = step 1 (events firing).

## Money — provenance warning
CAC $75 and conversion 2% are BOTH simulated. First win = make them HONEST, not lower.

## Links
- Skills that act: [[skills-index]] · Tracked by: [[coverage-tracker]]
