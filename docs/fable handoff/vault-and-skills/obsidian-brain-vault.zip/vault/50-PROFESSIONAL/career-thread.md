# Career Thread

> Lighter lane — story, not throughput. How the build compounds toward my positioning.
> Deliberately less metric-driven than the rest of the vault.

## The narrative
- Rare combo: enterprise-AI implementation + petroleum domain expertise. #known
- "I built a working digital-twin agent architecture" becomes evidence, not just infra. #known

## Active threads
- Technical paper for SPE/EAGE/WPC on redevelopment of underdeveloped reservoirs. #known
- Possible Anthropic role — strongest fits: Applied AI / Forward Deployed Engineering,
  Developer Relations. #known
- Executive positioning, world-class conference presence (EAGE, SPE, AAPG, WPC, ADIPEC, IPA). #known

## How the startup work feeds this
- Every Rail I lay (Circle HQ router, persona core, the skill system) is a portfolio artifact.
- [[TO FILL: Fable — connect specific builds to specific narrative beats]]

## Links
- Serves: [[persona-core]] (professional optimization goals)
